import re,json,os,datetime as dt,sys
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
REPO=r"C:\Users\NMO\Claude\Projects\2027 Term Planner"
B=r"C:\Users\NMO\Department of Education\8801-it - SouthOakleighCollege\2. Faculties\English\Year Level Folder"
# Term structure, same as TERMS in template.html
TERMS=[dict(n=1,start="2027-01-25",weeks=9,hol=[7,9],grey={},noL=[],exam=[]),
       dict(n=2,start="2027-04-12",weeks=11,hol=[10],grey={9:1,11:1},noL=[9],exam=[9]),
       dict(n=3,start="2027-07-12",weeks=10,hol=[],grey={},noL=[],exam=[]),
       dict(n=4,start="2027-10-04",weeks=11,hol=[5],grey={6:1,8:1,9:1,10:1,11:1},noL=[6,8,9,10,11],exam=[6])]
MON=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
def fmt(d): return f"{d.day} {MON[d.month-1]}"
def lessons(t,w):
    if w in t["noL"]: return []
    return ["Lesson I","Lesson II","Lesson III","Ad libitum"] if w in t["hol"] else ["Lesson I","Lesson II","Lesson III","Lesson IV"]
CAT=re.compile(r"^(S[12]_|EXAM)")
def units(store):
    out=[];cur=[]
    for t in TERMS:
        for w in range(1,t["weeks"]+1):
            if w in t["noL"] and w not in t["exam"]: continue
            k=f"{t['n']}--{w}"; cur.append((t,w,k))
            v=(store.get(k) or "").strip()
            if CAT.match(v):
                if not v.startswith("EXAM"): out.append(cur)
                cur=[]
    return out
def unit_name(store,u):
    v=(store[u[-1][2]] or "").strip(); i=v.find(":")
    return v if i<0 else v[i+1:].strip()
# ponytail: MAP is a hand-kept snapshot. Add a plan here before running; the site (template.html CM_FOLDERS) is the source of truth.
# Plan -> unit name (as shown on the site) -> folder under Year Level Folder
MAP={
 "09ADVEN1":{"NAPLAN Practice":("Year 9/Advanced English/Semester 1","1. NAPLAN Practice"),
   "Scene Analysis (12 Angry Men)":("Year 9/Advanced English/Semester 1","2. Scene Analysis (12 Angry Men)"),
   "Crafting Texts":("Year 9/Advanced English/Semester 1","3. Crafting Texts"),
   "Oral Presentation":("Year 9/Advanced English/Semester 1","4. Oral Presentation"),
   "Analysing Argument":("Year 9/Advanced English/Semester 2","1. Analysing Argument"),
   "Analytical Text Response Essay (Julius Caesar)":("Year 9/Advanced English/Semester 2","3. Julius Caesar")},
 "10ADVEN1":{"Personal Text Response Essay (Rear Window)":("Year 10/Advanced English/Semester 1","1. Rear Window"),
   "English Conventions":("Year 10/Advanced English/Semester 1","2. English Conventions"),
   "Love Framework of Ideas":("Year 10/Advanced English/Semester 1","3. Love Framework of Ideas"),
   "Oral Presentation":("Year 10/Advanced English/Semester 1","4. Oral Presentation"),
   "Early Modern English":("Year 10/Advanced English/Semester 2","1. Early Modern English"),
   "Analytical Text Response Essay (Macbeth)":("Year 10/Advanced English/Semester 2","2. Macbeth")},
 "09EN":{"Presenting Argument":("Year 9/English/Semester 1","1. Presenting Argument"),
   "Whale Rider Analytical Essay":("Year 9/English/Semester 1","2. Whale Rider"),
   "Creative Writing (Memoir)":("Year 9/English/Semester 1","3. Creative Writing (Memoir)"),
   "Animal Farm Analytical Essay":("Year 9/English/Semester 2","2. Animal Farm")}}
def build(code,store):
    made=0; names=[]
    for u in units(store):
        name=unit_name(store,u)
        if name not in MAP[code]: print("NO FOLDER:",code,name); continue
        sub,folder=MAP[code][name]
        d=Document()
        st=d.styles["Normal"]; st.font.name="Aptos"; st.font.size=Pt(10)
        h=d.add_heading(f"{code}: {name}",level=1)
        t0=u[0][0]; t1=u[-1][0]
        d.add_paragraph(f"Lesson plans. Term {u[0][0]['n']} Week {u[0][1]} to Term {u[-1][0]['n']} Week {u[-1][1]} ({len(u)} weeks). Learning intentions, success criteria and Do Nows by week and lesson.")
        for n,(t,w,k) in enumerate(u,1):
            start=dt.date.fromisoformat(t["start"])+dt.timedelta(days=7*(w-1))
            topic=(store.get(k) or "").strip()
            d.add_heading(f"Week {n}: {topic}",level=2)
            d.add_paragraph(f"Term {t['n']}, Week {w} (Monday {fmt(start)})")
            for i,lname in enumerate(lessons(t,w),1):
                kk=f"{t['n']}-{w}-{i}"
                title=(store.get(kk+"-title") or "").strip()
                li=(store.get(kk+"-li") or "").strip()
                sc=[s.strip() for s in (store.get(kk+"-sc") or "").split("|") if s.strip()]
                dn=(store.get(kk+"-dn") or "").strip()
                p=d.add_paragraph(); r=p.add_run(title or lname); r.bold=True
                if not (li or sc or dn):
                    p.add_run("  (not yet entered)").italic=True; continue
                if li: d.add_paragraph().add_run("Learning Intention: ").bold=True; d.paragraphs[-1].add_run(li)
                if sc:
                    d.add_paragraph().add_run("Success Criteria:").bold=True
                    for s in sc: d.add_paragraph(s,style="List Bullet")
                if dn: d.add_paragraph().add_run("Do Now: ").bold=True; d.paragraphs[-1].add_run(dn)
        folder_path=os.path.join(B,sub,folder,"Lesson Plans")
        os.makedirs(folder_path,exist_ok=True)
        out=os.path.join(folder_path,f"{code} - {name} - Lesson Plans.docx".replace("/"," ").replace(":",""))
        d.save(out); made+=1; names.append(os.path.relpath(out,B))
    return made,names
if __name__=="__main__":
    for code in sys.argv[1:]:
        s=open(os.path.join(REPO,code+".html"),encoding="utf-8").read()
        store=json.loads(re.search(r"^const SAVED=(\{.*\});$",s,re.M).group(1))
        m,names=build(code,store); print(code,"built",m)
        for n in names: print("  ",n)
