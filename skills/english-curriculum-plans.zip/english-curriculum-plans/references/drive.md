# The English drive folders

Root: `C:\Users\NMO\Department of Education\8801-it - SouthOakleighCollege\2. Faculties\English\Year Level Folder`

The folders were set up to match Maths (`2. Faculties\Maths\Year Level Folder\Year 10\Math\Semester 1`), which is the model. HPE uses a different layout and is not the model for names.

## Layout

```
Year 9/
  Advanced English/            (or "English" for Mainstream)
    Semester 1/
      Curriculum Map/          ONE semester curriculum map (.docx)
      Exam/                    exams, if any
      1. Unit name/
        Assessments & Rubrics/
        Class Resources/
        Lesson Plans/
        Unit Plan/              (see the open question below)
      2. Unit name/
    Semester 2/
      ...
```

- Units are numbered in teaching order within each semester: `1. NAPLAN Practice`, `2. Scene Analysis (12 Angry Men)`.
- Unit folder names are the unit names as the plan's CAT titles give them, not the generic "Unit of Work N".
- Each unit has the three standard subfolders. Add any that are missing.
- Years 7 and 8 use the same layout, and the year folders are lettered on the drive (`a. Year 7`, `c. Year 9`). Check the actual folder name before using a path. The user renamed these once, and the scripts broke.

## Semester and cross-semester units

- A unit goes in the semester of its CAT (`S1_` or `S2_`).
- A unit whose lessons start in one semester and whose CAT is in the other keeps the home copy in the CAT's semester. Put a copy in the other semester's folder, named the same, so students find it there. This was done for Year 7 Visual Persuasion, Year 8 The Giver Essay, Year 7 His Name was Walter, and the Memoir / Film units.
- The curriculum map links for a cross-semester unit go to the semester folder where its CAT sits.

## Files in each unit

- Unit plan: named `<CODE> Unit Plan - <Unit name>.docx` (the school's convention for Year 7 and 8). Earlier, the 09/10 plans used `<CODE> v2 <n> <unit>.docx` from the export; rename to the convention on placement.
- Lesson plans: `<CODE> - <unit name> - Lesson Plans.docx` in `Lesson Plans`, from `lesson_plans.py`.
- CAT brief: `<CODE> - <unit name> - CAT Assessment.docx` in `Assessments & Rubrics`, from `cat_briefs.py`. Check the name in `cat_briefs.py` before placing, because it has been changed before.
- Class resources: texts (Calibre EPUB and PDF copies), LitCharts guides, and `.url` shortcuts. Keep existing files. Never overwrite a file that is already in the folder without saying so.

## Open question: where do unit plans go?

The user's rules have changed over time:
- The Year 7 and 8 work, and the most recent Year 10 Mainstream placement, put unit plans in a `Unit Plan` subfolder inside each unit. The user asked for this layout ("Look at what I did with unit plans in folders").
- The 09ADVEN1, 10ADVEN1 and 09EN unit plans were placed directly in each semester's `Curriculum Map` folder, which the user later said should hold only the curriculum map.

Before placing unit plans, check the current state of the folder and ask the user which rule to follow. The default is the `Unit Plan` subfolder.

## Placement script pattern

Write one script per plan. Keep its folder map (`MAP` in `lesson_plans.py`, the same names as `CM_FOLDERS` in the template) in one place, and check each folder exists before writing. The example for Year 7 English (`scripts/place_example_07en.py`) shows the steps:
1. Tidy existing folders: rename to the unit names, and remove only files the user has approved (2026 leftovers, for example).
2. Create any missing unit folders and subfolders.
3. Copy the generated files from scratch into their unit folders, using exact names.
4. List what was left alone, including empty folders that could not be deleted.
5. Check every file opens and every curriculum map link resolves.

Run a dry run that prints every action first. Read it. Then run it.

## Known blockers

- Deleting a folder can fail with "Access denied", or be blocked by the sandbox. Do not retry through a shell. Report the folder and ask the user to delete it.
- Empty leftover "3. Unit of Work 3" folders in English Year 7 Semester 2 were still there at the last check. Ask the user to remove them.
- `Holes` was removed from Year 8 English, as the text is no longer studied. The Calibre copy stays in the library.
- Year 10 Mainstream Semester 1 `Catching Teller Crow` was deleted with the user's approval. Do not recreate it.

## Things never to do on the drive

- Do not touch other subjects' folders (Maths, HPE) unless asked.
- Do not delete the school's own files (for example `09ADVEN Unit Plan.docx` and `10ADVEN Unit Plan S1.docx`). Ask first.
- Do not keep copies of old-named files next to new ones. Remove stale copies only with approval, and check the correct replacements are present first.
