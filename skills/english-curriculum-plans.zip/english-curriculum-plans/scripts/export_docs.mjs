// Generate the Word documents the site's own buttons make, without a browser.
// Usage: node export_docs.mjs <path-to-plan.html> <outdir>
// Writes: units.json (every unit, first lesson to CAT),
//         "<CODE> Semester 1 Curriculum Map.docx", "<CODE> Semester 2 Curriculum Map.docx",
//         "<CODE> v2 <index> <unit name>.docx" (one unit plan per unit, index = position in units.json).
// It runs the plan's own code from template.html, so the output always matches the site.
import fs from "fs";
import vm from "vm";
import path from "path";

const [, , plan, outdir] = process.argv;
if (!plan || !outdir) { console.error("usage: node export_docs.mjs <plan.html> <outdir>"); process.exit(1); }
fs.mkdirSync(outdir, { recursive: true });

const src = fs.readFileSync(plan, "utf8");
const store = JSON.parse(src.match(/^const SAVED=(\{.*\});$/m)[1]);
const code = src.match(/<title>(.*?)<\/title>/)[1].split(" ")[0];
const _st = src.indexOf("<script>") + 8;
const script = src.slice(_st, src.indexOf("</script>", _st));
const cut = (a, b) => {
  const i = script.indexOf(a), j = script.indexOf(b, i + 1);
  if (i < 0 || j < 0) throw new Error(`anchor not found: ${a} / ${b}`);
  return script.slice(i, j);
};
const parts = [
  cut("const TERMS=", "let dirty"),
  cut("const MONTHS", "function setStatus"),
  cut("function units()", "// Curriculum map (Word)"),
  cut("// Curriculum map (Word)", 'document.getElementById("cmbtn")'),
  cut("// Unit plans (Word): one document", 'document.getElementById("upv2btn")'),
].join("\n");

const stubEl = () => ({ style: {}, classList: { add() {}, remove() {}, toggle() {} }, addEventListener() {},
  querySelector() { return stubEl(); }, querySelectorAll() { return []; }, appendChild() {}, insertAdjacentHTML() {},
  setAttribute() {}, getAttribute() { return null; }, dataset: {} });
const sandbox = {
  addEventListener() {}, setTimeout,
  document: { title: src.match(/<title>(.*)<\/title>/)[1], getElementById: () => stubEl(), addEventListener() {},
    querySelector: () => stubEl(), querySelectorAll: () => [], createElement: () => stubEl(), body: stubEl(),
    documentElement: stubEl(), head: stubEl() },
  location: { search: "", hostname: "localhost", hash: "" },
  URLSearchParams, Date, Set, Map, TextEncoder, Blob, console, Math, JSON, Object, Array, String, Number, RegExp, Promise,
};
vm.createContext(sandbox);
vm.runInContext(parts + "\n;this.units=units;this.unitName=unitName;this.cmDocx=cmDocx;this.unitDocxV2=unitDocxV2;", sandbox);

// 1. Units, in the order the site lists them (dump for checking)
const us = sandbox.units();
const list = us.map((u) => ({ name: sandbox.unitName(u), weeks: u.map((x) => `T${x.t} W${x.w} ${(store[x.k] || "").trim()}`) }));
fs.writeFileSync(path.join(outdir, "units.json"), JSON.stringify(list, null, 1), "utf8");

// 2. Curriculum maps, one per semester
for (const sem of [1, 2]) {
  const buf = Buffer.from(await sandbox.cmDocx(sem).arrayBuffer());
  fs.writeFileSync(path.join(outdir, `${code} Semester ${sem} Curriculum Map.docx`), buf);
}

// 3. Unit plans, one per unit
let i = 0;
for (const u of us) {
  const buf = Buffer.from(await sandbox.unitDocxV2(u).arrayBuffer());
  const name = `${code} v2 ${i} ${sandbox.unitName(u)}.docx`.replace(/[\/:*?"<>|]/g, "_");
  fs.writeFileSync(path.join(outdir, name), buf);
  i++;
}
console.log(`${code}: ${us.length} units, 2 curriculum maps written to ${outdir}`);
