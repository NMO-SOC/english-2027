from docx import Document
from docx.shared import Pt
import datetime
import os,re,json,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))  # lesson_plans.py lives next to this file
import lesson_plans as L
L.MAP["09ADVEN1"]["Oral Presentation"]=("Year 9/Advanced English/Semester 2","1. Oral Presentation")
L.MAP["09ADVEN1"]["Analysing Argument"]=("Year 9/Advanced English/Semester 2","2. Analysing Argument")
L.MAP["10ADVEN1"]["Oral Presentation"]=("Year 10/Advanced English/Semester 2","1. Oral Presentation")
L.MAP["10ADVEN1"]["Early Modern English"]=("Year 10/Advanced English/Semester 2","2. Early Modern English")
L.MAP["10ADVEN1"]["Analytical Text Response Essay (Macbeth)"]=("Year 10/Advanced English/Semester 2","3. Macbeth")
L.MAP["09EN"]["Creative Writing (Memoir)"]=("Year 9/English/Semester 2","1. Creative Writing (Memoir)")
MISSING="Assessment details not yet entered in the plan."
def brief(code,store,u,folder_path,name):
    last=u[-1]; t,w,k=last
    cat=(store.get(k) or "").strip()
    d=Document(); st=d.styles["Normal"]; st.font.name="Aptos"; st.font.size=Pt(10)
    d.add_heading(f"{code}: {cat}",level=1)
    d.add_paragraph(f"Unit of work: {name}")
    start=__import__("datetime").date.fromisoformat(t["start"])+__import__("datetime").timedelta(days=7*(w-1))
    d.add_paragraph(f"Due: Term {t['n']}, Week {w} (Monday {L.fmt(start)})")
    codes=(store.get("codes-"+k) or "").strip()
    d.add_heading("Curriculum codes",level=2)
    d.add_paragraph(codes or "Not yet entered.")
    d.add_heading("Assessment details",level=2)
    info=(store.get("info-"+k) or "").strip()
    if info:
        for line in info.split("\n"):
            if line.strip(): d.add_paragraph(line.strip())
    else: d.add_paragraph(MISSING)
    d.add_heading("Rubric",level=2)
    d.add_paragraph("To be added.")
    os.makedirs(folder_path,exist_ok=True)
    out=os.path.join(folder_path,f"{code} - {name} - CAT Assessment.docx")
    d.save(out); return out
tot=0
if __name__!="__main__": pass
for code in ["09ADVEN1","10ADVEN1","09EN"]:
    s=open(os.path.join(L.REPO,code+".html"),encoding="utf-8").read()
    store=json.loads(re.search(r"^const SAVED=(\{.*\});$",s,re.M).group(1))
    for u in L.units(store):
        name=L.unit_name(store,u)
        sub,folder=L.MAP[code][name]
        p=os.path.join(L.B,sub,folder,"Assessments & Rubrics")
        out=brief(code,store,u,p,name); tot+=1
        has=bool((store.get("info-"+u[-1][2]) or "").strip())
        print(("OK  " if has else "NO DETAILS  "), os.path.relpath(out,L.B))
print("total",tot)
