# The generated documents

## Terms used everywhere

- **Unit of work**: from the first teaching lesson after the previous CAT, through to its CAT. The CAT ends the unit. Exams are never part of a unit. Units can span a term break or the semester break.
- **Learning intention (LI)**: the "We will…" sentence for a lesson.
- **Success criteria (SC)**: "I can…" statements, separated by ` | ` in the plan data.
- **Do Now**: the short starter task at the start of a lesson.

## Lesson style (for drafting plan content)

The existing Advanced and Mainstream plans set the pattern. Follow it:
- LI starts "We will…".
- Three SC, each starting "I can…".
- Do Now is a short starter task, one or two lines.
- Four lessons per week. Short weeks have three lessons plus Ad libitum.
- CAT weeks: prep lessons, then two CAT lessons, then a reflection.
- Lesson titles name the focus (a scene, a chapter, a skill). A film unit uses CAMELS+D.

Every lesson drafted this way is a draft. Say so.

## Curriculum map (school template, one per semester)

Built from `Curriculum Map template.docx` by the site's own code (`export_docs.mjs`, the "Curriculum map (Word)" button produces the same file). One row per week.

Columns:
- **Week**: week number, term week, and the Monday's date.
- **Topic / Links to VIC Curriculum**: weekly topic, then its codes.
- **Learning Intentions and Success Criteria**: up to three of each for the week.
- **Key Knowledge**: the lesson title if entered, otherwise the lesson's LI reworded (drop "We will", drop the verb, capitalise the rest). Do not show "to be added"; derive it.
- **Link to Lesson plans**: relative link to that unit's lesson plan document, which must sit in the same folder structure.
- **Do Now**: each lesson's Do Now, labelled by lesson title or numeral.
- **Assessment**: CAT weeks only, with a relative link to the CAT brief.

Rules:
- One file per semester. Semester 1 is Terms 1 and 2. Semester 2 is Terms 3 and 4.
- Grey weeks (Exams, Set-Up, Clean-Up, Activities) are included with their labels.
- Step-Up weeks are left out of Semester 2.
- A unit that spans the semester break is linked to the semester of its CAT.
- The map must save into its semester's `Curriculum Map` folder, because its links are relative.

## Unit plan (school template, one per unit)

Built from `Unit Plan document template.docx`. Five sections, in this order:

1. **Adjustments for students**: three columns, EAL, Integration (formerly special needs) and Extension. Write guidance drawn from the unit's own topic. Film units suggest CAMELS+D supports. Oral units suggest rehearsal and audience-question options. Draft.
2. **Curriculum mapping**: the Victorian Curriculum 2.0 English codes for the unit, with their achievement standard for Levels 9 and 10. Achievement standards are drafts (see `codes.md`).
3. **Topic strip**: the strand (Literature, Language or Literacy, from the codes), the recommended teaching time in weeks, and the sub-strand from the unit's topics.
4. **Big idea and essential understandings**: the big idea says what students do in the topic. Essential understandings are ONE learning intention and ONE success criterion that summarise the whole unit. Do not list every lesson's LI.
5. **Cross-curriculum priorities, capabilities and 21CLD**: tick boxes. Mark these as keyword-based ticks for the user to check, especially 21CLD.
6. **Common assessments**: pre-assessment (the unit's first Do Now, or a diagnostic prompt), formative (a check against the success criteria across the unit), and summative (the CAT).

The user has approved this layout. Do not add "to be added" placeholders. Fill every section, and say which parts are drafts.

## Lesson plan document

Built by `scripts/lesson_plans.py`. One document per unit, with every week and lesson listing its LI, SC and Do Now. Lessons with nothing entered say "(not yet entered)". Use this only as a working file until the lessons are written on the site.

## CAT brief

Built by `scripts/cat_briefs.py`. One per CAT, in its unit's `Assessments & Rubrics` folder. Contains the CAT title, unit name, due week and Monday's date, curriculum codes, and assessment details from the plan. If the plan has no details, say so in the brief. The rubric heading says "To be added" until the rubric is supplied.

## Learning Area Plan (school template, one for all classes)

Built from the site's "Learning area plan (Word)" button in `english.html`. One block per class, Years 7 to 10. Each block has a row for each semester:
- **Topic / Subject** row: each week's topic.
- **Curriculum 2.0 codes** row: the codes in a box underneath.
- Both rows are coloured by unit of work, with the whole cell shaded, not just the codes box. A colour key sits under the table.
- An **Exam Revision** column at the end of each semester lists that semester's exam.
- Header with the Victorian Curriculum logo, title with the school logo, and the VCAA copyright footer come from the template.

Years 7 and 8 blocks stay blank until their plans exist.

## Checking any document

- The file opens as a zip (`zipfile.ZipFile(f).testzip()` returns None).
- No table cell is empty (each cell has a paragraph).
- Every link resolves from the folder it sits in.
- Re-open one document and read a sample of text against the plan, to confirm the content is the plan's own.
- The user has not yet been able to open these in Word from the sandbox. Say that you could not check layout in Word.
