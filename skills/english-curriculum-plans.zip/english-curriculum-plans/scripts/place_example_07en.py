import os, re, sys, json, shutil, datetime as dt
from docx import Document
from docx.shared import Pt
sys.path.insert(0, r"C:\Users\NMO\AppData\Local\Temp")
import lessonplans as L

TEMP = r"C:\Users\NMO\AppData\Local\Temp"
GEN = os.path.join(TEMP, "gen")
B = L.B
Y7E = os.path.join(B, "Year 7", "English")
S1 = os.path.join(Y7E, "Semester 1")
S2 = os.path.join(Y7E, "Semester 2")
CODE = "07EN"

def fs(n):  # same as the site's fileSafe: ":" becomes " -"
    return re.sub(r'[\\/*?"<>|]', "", n.replace(":", " -")).replace("  ", " ").strip()

def ensure_subs(folder):
    for s in ("Assessments & Rubrics", "Class Resources", "Lesson Plans", "Unit Plan"):
        os.makedirs(os.path.join(folder, s), exist_ok=True)

# ---- 1. tidy the existing folders ----
def rename(old, new):
    if os.path.isdir(old) and not os.path.exists(new):
        os.rename(old, new); print("renamed ->", os.path.relpath(new, B))
rename(os.path.join(S1, "1. Coraline"), os.path.join(S1, "1. Coraline Comprehension Questions"))
rename(os.path.join(S1, "2. Persuasive Pitch"), os.path.join(S1, "2. Persuasive Poster"))
for stale in [
    os.path.join(S1, "1. Coraline Comprehension Questions", "Assessments & Rubrics", "CoralineCAT.docx"),
    os.path.join(S1, "2. Persuasive Poster", "Assessments & Rubrics", "S1_07EN_CAT1-Persuasive Advertisement Pitch.docx"),
    os.path.join(S1, "Curriculum Map", "SOC Year 7 English Term 2 Unit Plan- Coraline.docx"),
]:
    if os.path.isfile(stale):
        os.remove(stale); print("removed (2026):", os.path.basename(stale))
generic = sorted([d for d in os.listdir(S2) if re.match(r"^\d+\. Unit of Work \d+$", d)], key=lambda d: int(d.split(".")[0]))
if len(generic) >= 2:
    rename(os.path.join(S2, generic[0]), os.path.join(S2, "1. His Name was Walter TEEL Paragraph"))
    rename(os.path.join(S2, generic[1]), os.path.join(S2, "2. Article Analysis Podcast"))
for extra in generic[2:]:
    p = os.path.join(S2, extra)
    assert not [f for _, _, fs_ in os.walk(p) for f in fs_], p
    print("empty leftover folder (not deleted, please remove):", os.path.relpath(p, B))
for name in ["1. Coraline Comprehension Questions", "2. Persuasive Poster",
             "1. His Name was Walter TEEL Paragraph", "2. Article Analysis Podcast", "3. His Name was Walter TEEL Paragraph"]:
    d = os.path.join(S1 if name[0] in "123" and "Coraline" in name or "Persuasive" in name or name.startswith("3.") else S2, name)
    ensure_subs(d)

# ---- 2. the units, from the site ----
s = open(os.path.join(L.REPO, CODE + ".html"), encoding="utf-8").read()
store = json.loads(re.search(r"^const SAVED=(\{.*\});$", s, re.M).group(1))
raw = json.load(open(os.path.join(TEMP, "units_07EN.json"), encoding="utf-8"))
TD = {t["n"]: t for t in L.TERMS}
def tdict(n):
    d = dict(TD[n])
    d["noL"] = list(d["noL"]); d["hol"] = list(d["hol"]); d["exam"] = list(d["exam"])
    return d
TD = {n: tdict(n) for n in TD}
units = []
for item in raw:
    u = []
    for wk in item["weeks"]:
        m = re.match(r"T(\d) W(\d+)", wk); n, w = int(m.group(1)), int(m.group(2))
        u.append((TD[n], w, f"{n}--{w}"))
    units.append((fs(item["name"]), u))
HOME = {
    "Coraline - Comprehension Questions": ("Year 7/English/Semester 1", "1. Coraline Comprehension Questions"),
    "Persuasive Poster": ("Year 7/English/Semester 1", "2. Persuasive Poster"),
    "His Name was Walter TEEL Paragraph": ("Year 7/English/Semester 2", "1. His Name was Walter TEEL Paragraph"),
    "Article Analysis Podcast": ("Year 7/English/Semester 2", "2. Article Analysis Podcast"),
}
COPY = {"His Name was Walter TEEL Paragraph": ("Year 7/English/Semester 1", "3. His Name was Walter TEEL Paragraph")}
for name, (sub, folder) in HOME.items():
    ensure_subs(os.path.join(B, sub, folder))
for name, (sub, folder) in COPY.items():
    ensure_subs(os.path.join(B, sub, folder))
L.MAP[CODE] = dict(HOME)
objs = {id(u): name for name, u in units}
lst = [u for _, u in units]
L.units = lambda st: lst
L.unit_name = lambda st, uu: objs[id(uu)]

# ---- 3. lesson plans and CAT briefs ----
_orig_lessons = L.lessons
L.lessons = lambda t, w: _orig_lessons(t, w)[:2] if (t["n"], w) == (1, 2) else _orig_lessons(t, w)
made, names = L.build(CODE, store)
print("lesson plan docs:", made)

def brief(u, folder_path, name):
    t, w, k = u[-1]
    cat = (store.get(k) or "").strip()
    d = Document(); st = d.styles["Normal"]; st.font.name = "Aptos"; st.font.size = Pt(10)
    d.add_heading(f"{CODE}: {cat}", level=1)
    d.add_paragraph(f"Unit of work: {name}")
    start = dt.date.fromisoformat(t["start"]) + dt.timedelta(days=7 * (w - 1))
    d.add_paragraph(f"Due: Term {t['n']}, Week {w} (Monday {L.fmt(start)})")
    codes = (store.get("codes-" + k) or "").strip()
    d.add_heading("Curriculum codes", level=2); d.add_paragraph(codes or "Not yet entered.")
    d.add_heading("Assessment details", level=2)
    info = (store.get("info-" + k) or "").strip()
    lines = [l.strip() for l in info.split("\n") if l.strip()]
    for line in lines or ["Assessment details not yet entered in the plan."]:
        d.add_paragraph(line)
    d.add_heading("Rubric", level=2); d.add_paragraph("To be added.")
    os.makedirs(folder_path, exist_ok=True)
    out = os.path.join(folder_path, f"{CODE} - {name} - CAT Assessment.docx")
    d.save(out); return out

for name, u in units:
    sub, folder = HOME[name]
    print("brief:", os.path.relpath(brief(u, os.path.join(B, sub, folder, "Assessments & Rubrics"), name), B))

# ---- 4. unit plans from the site ----
up_dir = os.path.join(GEN, "up07EN")
files = sorted([f for f in os.listdir(up_dir) if re.match(CODE + r" v2 \d+ ", f)],
               key=lambda f: int(re.match(CODE + r" v2 (\d+) ", f).group(1)))
assert len(files) == len(units), (len(files), len(units))
for f, (name, u) in zip(files, units):
    sub, folder = HOME[name]
    dst = os.path.join(B, sub, folder, "Unit Plan", f"{CODE} Unit Plan - {name}.docx")
    shutil.copy2(os.path.join(up_dir, f), dst); print("unit plan:", os.path.relpath(dst, B))
    if name in COPY:
        csub, cfolder = COPY[name]
        dst2 = os.path.join(B, csub, cfolder, "Unit Plan", f"{CODE} Unit Plan - {name}.docx")
        shutil.copy2(os.path.join(up_dir, f), dst2)
        src_lp = os.path.join(B, sub, folder, "Lesson Plans", f"{CODE} - {name} - Lesson Plans.docx")
        shutil.copy2(src_lp, os.path.join(B, csub, cfolder, "Lesson Plans", os.path.basename(src_lp)))
        src_cat = os.path.join(B, sub, folder, "Assessments & Rubrics", f"{CODE} - {name} - CAT Assessment.docx")
        shutil.copy2(src_cat, os.path.join(B, csub, cfolder, "Assessments & Rubrics", os.path.basename(src_cat)))
        print("copied to Semester 1:", cfolder)

# ---- 5. curriculum maps: one per semester, in the Curriculum Map folder only ----
for sem in (1, 2):
    src = os.path.join(GEN, "cm07EN", f"{CODE} Semester {sem} Curriculum Map.docx")
    cm = os.path.join(Y7E, f"Semester {sem}", "Curriculum Map")
    for f in os.listdir(cm):
        os.remove(os.path.join(cm, f))  # replace last run's curriculum map
    dst = os.path.join(cm, os.path.basename(src))
    shutil.copy2(src, dst); print("curriculum map:", os.path.relpath(dst, B))
