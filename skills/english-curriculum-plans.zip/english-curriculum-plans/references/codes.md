# Curriculum codes (VC 2.0 English)

## Where codes come from

Use only the codes in `C:\Users\NMO\Downloads\English Levels 7–10 (content descriptions)_13-12-2023.docx`. That file is the VCAA Victorian Curriculum 2.0 content descriptions for English, Levels 7 to 10. Open it and search by code before using one. Do not write a code from memory.

## Format

`VC2E9LA07` reads as:
- `VC2` the Victorian Curriculum 2.0 prefix
- `E` English
- `9` the level (Year 9). Year 7 is `7`, and so on.
- `LA` the strand, from the content descriptions: `LA` Language, `LE` Literature, `LY` Literacy
- `07` the item number

Some plans use `09EN` and `10EN` for their own CAT code prefixes. That is the plan's code, not a curriculum code. Keep the two apart.

## How to choose codes for a week

- Match the week's topic to the content description it teaches. A week on persuasive language points to the Language descriptions for that level. A film or novel week points to Literature descriptions.
- Two or three codes per week is the usual pattern in the plans. Do not put every code for the strand in one week.
- Each CAT's details end with `Curriculum codes: …`, listing the codes that CAT assesses, as the Advanced plans do.
- Check that every code in the plan appears in the content-descriptions file. A typo here shows the user's school a wrong code.

## Checking coverage

For each plan, the set of codes used across the year should cover what the year level must teach. The site does not check this for you. If the user asks for a coverage check, list each code used with its weeks, then list the codes from the level that were never used, and ask which are wanted. Do not add codes just to fill the list.

## Achievement standards

The achievement standard wording in the unit plan template (Levels 9 and 10) is not VCAA text. Those statements are drafts. Say so in every reply that includes them, and ask the user to check them against the official Victorian Curriculum 2.0 achievement standards.
