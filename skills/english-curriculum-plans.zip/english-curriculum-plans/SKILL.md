---
name: english-curriculum-plans
description: Build and maintain the South Oakleigh College 2027 English curriculum plans end to end. Use this whenever the user mentions a year level plan (Year 7 to 10, Mainstream or Advanced, codes like 07EN, 08ADVEN1, 09EN, 10ADVEN1), adding or changing CATs, exams, weekly topics, lessons, learning intentions, success criteria, Do Nows, VC 2.0 curriculum codes, unit plans, curriculum maps, lesson plans, CAT briefs, the Learning Area Plan, the English overview page, or putting any of these into the English drive folders under "Year Level Folder". Also use it for "do the same for 10 mainstream", "make a plan for year X", or any new subject built the same way, even when the user does not say "skill" or name the files.
---

# English curriculum plans (2027)

This skill covers the whole chain: a plan page on the site, its curriculum codes, the Word documents the site produces (curriculum map, unit plan), the lesson plan and CAT brief files, and placing them in the drive folders. The site is the source of truth. Every Word document is generated from the plan's own data, so fix the data first and regenerate.

Read the reference files only when you need them:
- `references/site-plan.md`: building or editing a plan page, the data keys, the calendar, and registering a new plan on the homepage and overview.
- `references/codes.md`: finding and checking VC 2.0 curriculum codes.
- `references/documents.md`: what each generated document contains and the writing rules.
- `references/drive.md`: the drive folder layout, naming, placement rules, and known blockers.

## Locations

- Repo (GitHub Pages site, `NMO-SOC/english-2027`): `C:\Users\NMO\Claude\Projects\2027 Term Planner`. `template.html` is the only design source. `build.py` rebuilds each plan from it. `README.md` is the manual; keep it current.
- Drive root: `C:\Users\NMO\Department of Education\8801-it - SouthOakleighCollege\2. Faculties\English\Year Level Folder`.
- Source documents: `C:\Users\NMO\Downloads`. Curriculum content descriptions: `English Levels 7–10 (content descriptions)_13-12-2023.docx`. School templates: `Curriculum Map template.docx`, `Unit Plan document template.docx`, `Learning Area Plan.docx`.
- Scripts in this skill: `scripts/export_docs.mjs` (curriculum maps and unit plans, run through the site's own code), `scripts/lesson_plans.py` (lesson plan documents), `scripts/cat_briefs.py` (CAT briefs), `scripts/place_example_07en.py` (an example of one plan's placement script, to copy from).

## Rules that override everything else

1. **Never change entered data.** Before any edit, snapshot the `const SAVED=`, `const DEFAULTS=`, `<title>` and `<h1>` lines of every plan you touch. Afterwards, confirm they are byte-identical, except where the user asked for that exact data to change. Say what you checked.
2. **Always commit and push** after a repo change. Change nothing the user did not ask for.
3. **The live site is read-only.** Visitors cannot type or save. The user edits local copies and pushes. Do not propose live editing.
4. **Never delete files or folders without explicit go-ahead.** The sandbox often blocks deletes with "Access denied". When that happens, stop, list what needs removing, and ask the user to delete it. Do not work around the block.
5. **Never invent a curriculum code, a text, or a rubric.** Codes come from the content-descriptions document. Any drafted lesson content, achievement standard, or adjustment must be flagged as a draft in your reply.
6. **Semester comes from the CAT prefix.** `S1_` is Semester 1, `S2_` is Semester 2. Do not decide the semester from where a unit starts. A unit that spans the break is placed by its CAT, and its copy in the other semester is handled as described in `references/drive.md`.
7. **Step-Up weeks start the next semester.** They are left out of Semester 2 curriculum maps and out of Semester 2 units.
8. **Exam weeks are never part of a unit.** Revision weeks go into the unit that follows the previous CAT, or are left out, as the user directs.

## Workflow for a plan

Work in this order. Each step checks the one before it.

**1. Gather inputs.** You need the 2027 CAT list (title, term and week), the exam weeks, any camp, induction or Step-Up weeks, the texts, and the source documents for lesson content. If the user gives a 2026 assessment screenshot, map each item to the 2027 week containing the same date, and ask about anything unclear. If the user gives a week, that wins over the date.

**2. Build the plan page.** Create the file from `template.html` and run `build.py`, following `references/site-plan.md`. Set the title and `<h1>`. Enter weekly topics, CATs (`S1_`, `S2_`, `EXAM` prefixes), calendar overrides and per-plan settings. Then run `python build.py <plan>.html` and confirm the data lines did not change except where intended.

**3. Add curriculum codes.** Every teaching week gets its VC 2.0 codes, and each CAT's details end with `Curriculum codes: …`. Follow `references/codes.md`.

**4. Write lessons.** Every teaching week has four lessons (three plus Ad libitum in short weeks). Each lesson has a learning intention, success criteria and a Do Now, written in the same style as the existing plans (`references/documents.md` has the style rules). Lesson titles are optional. Mark all drafted lesson content as draft in your reply.

**5. Register the plan on the site.** Check all four places:
- `index.html`: the plan's card links to the plan, not "Coming soon". This file keeps its own copy of `TERMS`, which must match `template.html`.
- `english.html`: add the class to `CLASSES` and `LAP_YEARS`, and check the overview's calendar logic picks up any per-plan overrides.
- `template.html`: `CM_FOLDERS` needs an entry for each unit, with the drive folder names exactly as they are on the drive. Check the list for missing commas, which break the page script for every plan.
- `README.md`: the plan list and anything a teacher would need to know.

**6. Verify the site.** Syntax-check the page script, confirm every teaching week has lessons (except the week after the last exam), confirm no grey week carries lessons, then run `node scripts/export_docs.mjs <plan>.html <scratch>`. If the export runs without error, the units and documents build. Push, then check the live page after a minute or two. If it looks old, the user should hard-refresh.

**7. Generate the documents, into a scratch folder first.**
- Curriculum maps and unit plans: `node scripts/export_docs.mjs <plan>.html <scratch>`. This writes `units.json`, one curriculum map per semester, and one unit plan per unit.
- Lesson plans: `scripts/lesson_plans.py`. Its `MAP` dictionary must already list the plan's units and their drive folders.
- CAT briefs: `scripts/cat_briefs.py`, using the same `MAP`.
- Check every output is a valid zip (`zipfile.ZipFile(f).testzip()` returns None). No lesson should say "not yet entered" unless the user has not supplied it yet.

**8. Place the files on the drive.** Follow `references/drive.md`. Write a placement script that copies from scratch into the unit folders, creates missing subfolders, and reports anything it does not move. Run it as a dry run first, read the action list, then run it for real. Check each curriculum map link resolves from the folder it sits in.

**9. Resources (only if asked).** Copy matching Calibre books and LitCharts files into each unit's `Class Resources`, and add `.url` shortcuts for web links. Use only links you actually retrieved from search, and say they are unopened and may be paid, UK-based or out of date. Do not download study guides you cannot access legitimately.

**10. Report.** Finish with what changed, what you checked (data identical, files open, links resolve), what is still draft, and each decision the user needs to confirm, as short questions.

## Known traps

- In file names, `:` becomes ` -`, matching the site's file-safe names. Folder names must match exactly, because curriculum map links point at them.
- The sandbox can refuse deletes, including on folders with `&` in the name. Report it; do not retry through a shell.
- An unnamed "Unit of Work N" folder is not finished. Report it and ask what it is.
- Whale Rider is a film. Check any novel-only resource before adding it.
- Design changes go in `template.html` and are rebuilt with `build.py`. Never hand-edit the design of one plan.
- If a Word document will not open, the usual causes are empty table cells (each needs a paragraph), out-of-order formatting inside hyperlinks, and duplicate paragraph IDs in copied rows. `export_docs.mjs` runs the site's code, so a fix to the template fixes the output too.
