# Building and editing a plan page

## The files

- `template.html`: the only design source. Holds `TERMS`, the calendar, and all the page code. Holds no plan data.
- `build.py`: copies `template.html` into each plan and keeps four lines from the plan: `<title>`, the `<h1>` line, `const DEFAULTS=`, `const SAVED=`. It also keeps `const PLAN=` if the plan has one. It stops with an error if a kept line is missing or appears twice.
- Plan files: `09ADVEN1.html`, `10ADVEN1.html`, `07ADVEN1.html`, `08ADVEN1.html`, `07EN.html`, `08EN.html`, `09EN.html`, `10EN.html`. Each is the template plus its own data.
- `index.html`: homepage. Has its own copy of the term dates (`T=[...]`) that must match `TERMS`.
- `english.html`: the English overview. Reads each plan's data and calendar straight from the plan file, so plans need registering in `CLASSES` and `LAP_YEARS`.

Rebuild after any template change: `python build.py 07EN.html 08EN.html 09ADVEN1.html 09EN.html 10ADVEN1.html 10EN.html` (list every plan). Never edit a plan's design by hand.

## The calendar: `TERMS` in template.html

Each term has `n`, `start`, `weeks`, `hol`, `grey`, `noLessons`, `exam`, and `notes`. Example from the template: `grey:{6:"Exams",8:"Step-Up",9:"Step-Up",10:"Activities Week",11:"Clean-Up Week"}`, `noLessons:[6,8,9,10,11]`, `exam:[6]`.

A plan changes the calendar with `const PLAN={...}` on its own line. The setting names below are the ones the template reads:

| Setting | Format | Effect |
|---|---|---|
| `normalWeeks` | `[[term, week], ...]` | Removes the grey or exam marking, making the week a teaching week. Example: `[[2,9],[2,11]]`. |
| `greyWeeks` | `[[term, week, "Label"], ...]` | Greys a week with no lessons, e.g. induction or camp. |
| `notes` | `[[term, week, "Label"], ...]` | Labels a week, e.g. `"Starts Thu"` or `"Step-Up"`. |
| `lessonCount` | `[[term, week, n], ...]` | Limits a week to `n` lessons. |
| `noUnit` | `[[term, week], ...]` | The week has lessons but belongs to no unit (e.g. a post-exam week). |

Rules that come from the calendar:
- Term 1 Week 1 is induction for Year 7. Term 1 Week 5 is camp (24–26 Feb in 2027). Greying is done with `greyWeeks`.
- Year 7 has no exam in Semester 1, and no Term 2 Week 9 exam week, so `normalWeeks` makes those weeks teaching weeks.
- Step-Up (Term 4, Weeks 8–9) is the start of next year's Semester 1. Leave it out of Semester 2 documents.
- Term 4 Week 7 is after the last exam and has no lessons, as in every plan. That is expected.

## Data keys

Every value is stored in `const SAVED={...}` with these keys:
- `T--W`: the weekly topic, e.g. `"1--4"` is Term 1 Week 4. A topic starting `S1_`, `S2_` or `EXAM` becomes a CAT or exam badge.
- `info-T--W`: CAT or exam details (the assessment text).
- `codes-T--W`: the week's curriculum codes, e.g. `VC2E9LA07, VC2E9LE03`.
- `T-W-L-title`, `T-W-L-li`, `T-W-L-sc`, `T-W-L-dn`: lesson title, learning intention, success criteria (separated by ` | `), Do Now. `L` is the lesson number 1 to 4.

A CAT code looks like `S1_09EN_CAT1: Presenting Argument`. Use the prefix (`S1_`, `S2_`, `EXAM`) to say the semester. Keep the code format used by the other plans, which the user already knows from Compass.

## Adding a new plan

1. Copy `template.html`'s current structure into a new file named by code (`10EN.html`). Easiest: create the file with `build.py` from an existing plan's title and data, then clear its data. Or copy `template.html` and set `<title>` and `<h1>`.
2. Enter the topics, CATs, codes, lessons and calendar settings. Run `build.py` on the new file.
3. Register it as in SKILL.md step 5 (homepage card, `english.html`, `CM_FOLDERS`, README).
4. Check the page in a browser after pushing. Confirm `english.html` shows it, with no "Coming soon".

## Checking data did not change

Compare the four kept lines (`<title>`, `<h1>`, `DEFAULTS`, `SAVED`) before and after with a byte comparison of the saved file against the last commit. For a plan you did not touch, `git diff` should show no change to its `SAVED` line. When you did change data on purpose, show the user the diff of that line.
